package es.unex.cum.ada.pract2020_2021;

public class RootNode extends Node {


    @Override
    public NodeType getNodeType() {
        return NodeType.ROOTNODE;
    }


}
