package es.unex.cum.ada.pract2020_2021;

public class WordNode extends Node {
    @Override
    public NodeType getNodeType() {
        return NodeType.WORDNODE;
    }

}
